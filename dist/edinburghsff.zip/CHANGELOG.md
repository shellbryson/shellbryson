# Change Log - Edinburgh SF/F (Ghost Theme)

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [0.0.1] - 2019-09-11

### Add

- Initial version